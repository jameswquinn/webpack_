import $ from 'jquery';
import mapboxgl from 'mapbox-gl';
import * as firebase from 'firebase';
var zxcvbn = require('zxcvbn');
