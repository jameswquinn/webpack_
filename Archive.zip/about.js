import $ from 'jquery';
import * as firebase from 'firebase';
var zxcvbn = require('zxcvbn');
